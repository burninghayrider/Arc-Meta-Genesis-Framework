Placeholder content for Contributing_Guide.md
