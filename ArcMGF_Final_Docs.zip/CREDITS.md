Placeholder content for CREDITS.md
