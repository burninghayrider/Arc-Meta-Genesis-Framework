
from SimulationManager import SimulationManager
import ArcMGF_Simulation_Core as core
import yaml

# Load manager configuration
with open('manager_config.yaml', 'r') as f:
    config = yaml.safe_load(f)

# Initialize Simulation Manager
manager = SimulationManager(config)
manager.load_core(core)
manager.initialize_arcs()

# Run all arcs
results = manager.run_all_arcs()
print("Results:", results)

# Handle feedback (placeholder)
manager.handle_feedback(['anomaly1', 'anomaly2'])

# Export summary
summary = manager.export_summary(results)
print(summary)
