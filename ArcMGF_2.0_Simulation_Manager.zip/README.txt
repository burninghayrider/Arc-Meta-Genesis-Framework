
ArcMGF 2.0 Simulation Manager
=============================

This package provides a manager to run multiple synthesis arcs using the ArcMGF Simulation Core.

Contents:
- SimulationManager.py: Core manager class.
- manager_config.yaml: Configuration template.
- run_manager.py: Example workflow script.

Usage:
1. Ensure ArcMGF Simulation Core is available in the same directory.
2. Edit manager_config.yaml to set number of arcs and anchors.
3. Run: python run_manager.py

Integration:
- Use SimulationManager.load_core() to link with ArcMGF core.
- Extend SimulationManager for custom workflows.
