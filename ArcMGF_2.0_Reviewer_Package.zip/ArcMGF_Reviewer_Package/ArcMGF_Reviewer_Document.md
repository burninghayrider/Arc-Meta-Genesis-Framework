# ArcMGF 2.0 Reviewer Document

Includes all sections as specified.